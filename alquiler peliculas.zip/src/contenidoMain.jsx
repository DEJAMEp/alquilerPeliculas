import React from "react";

function MostrarPelis(props){
    return (
        <main>
            <div id="acapostre"> </div>
            <div className="card">
                <img className="imagen" src={props.imagenUrl} alt='planta' />
                <p className="nombre">{props.nombre}</p>
                <p className="edad"> {props.duracion}</p>
                <p className="ranking"> {props.ranking}</p>
                <p className="precio"> {props.precio}</p>
                <p className="calificacion"> {props.calificacion}</p>
                <section id="botoncitos">
                    <button className="btns" >Agregar a favoritos</button>
                    <button className="btns">Agregar a carrito</button>
                </section>
            </div>
        </main>
    )
}



 const CAP = [

    {
        "imagenUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLvji2wd-10HJfZtzVNtSEkgvoZgqOSfcEUg&usqp=CAU",
        "nombre": "Charlie y la fábrica de chocolates",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "5 *****",
        "precio": "$1000",
        "año": ""
        
    },
    {
        "imagenUrl": "https://www.luismaram.com/wp-content/uploads/2013/04/american_horror_story_ver11.jpg",
        "nombre": "American Horror Story",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": "",
        "precio": "$1000",
        
    },
    {
        "imagenUrl": "https://http2.mlstatic.com/D_NQ_NP_977509-MLA32210303564_092019-O.jpg",
        "nombre": "Stranger Things",
        "duracion":  "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": "",
        "precio": "$1000",
        
    },
    {
        "imagenUrl": "https://http2.mlstatic.com/D_NQ_NP_943372-MLA44786363558_022021-O.jpg",
        "nombre": "Riverdale",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": "",
        "precio": "$1000",
        
    },
    {
        "imagenUrl": "https://pbs.twimg.com/media/DxxaOupWoAALRBD.jpg:large",
        "nombre": "The Umbrella Academy",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "http://cdn5.upsocl.com/wp-content/uploads/2018/07/Captura-de-pantalla-2017-07-04-a-las-16.50.38.jpg",
        "nombre": "13 reasons why",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "ranking": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://http2.mlstatic.com/D_NQ_NP_808052-MLA42793635969_072020-O.jpg",
        "nombre": "Lucifer",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://http2.mlstatic.com/D_NQ_NP_870556-MLA43201144456_082020-O.jpg",
        "nombre": "Enola Holmes",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://cinergiaonline.com/wp-content/uploads/2017/12/american-vandal.jpg",
        "nombre": "American Vandal",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "http://cdn3.upsocl.com/wp-content/uploads/2018/07/Captura-de-pantalla-2017-07-04-a-las-16.51.34.jpg",
        "nombre": "We will bear no more",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://cinergiaonline.com/wp-content/uploads/2017/12/glow.jpg",
        "nombre": "Glow",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://dariuslacroix.files.wordpress.com/2016/01/love.jpg?w=584",
        "nombre": "Love",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://starwlog.files.wordpress.com/2018/06/kiss-me-first.jpg",
        "nombre": "Kiss me first",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://pbs.twimg.com/media/EA_Fd3KXoAAuz1e.jpg",
        "nombre": "¿Quién mató a Bryce Walker?",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },
    {
        "imagenUrl": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSCr-sbgp6tXUveT9PGEYLSCOP-KmHnQA5UA&usqp=CAU",
        "nombre": "West World",
        "duracion": "1h 54min",
        "sinopsis": "El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.El excéntrico Willy Wonka abre las puertas de su fábrica de chocolate a cinco suertudos niños. Quieran o no, aprenderán todos los secretos que esconde.",
        "protagonistas": "Johnny Depp,Freddie Highmore,David Kelly",
        "calificacion": "",
        "directora": "",
        "año": ""
    },

 ];
let filtercap = CAP.filter(
    nombre => nombre.nombre == nombre
);


 
 function Lista(datos) {
    return (
        <>
            {datos.array.map((planta) => {
                const { nombre, imagenUrl, duracion, ranking ,precio,calificacion} = planta;
                return (
                    <MostrarPelis nombre={nombre} imagenUrl={imagenUrl} key={nombre} duracion={duracion} ranking={ranking} precio={precio} calificacion={calificacion}/>
                )
            })}

        </>
    )
}

export default function AppJson() {
    return (
        <div id='grid'>
        <Lista  array={CAP} />
        </div>
  )
}