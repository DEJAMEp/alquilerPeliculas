import React from 'react';

import "./index.css"


export default function IniciarSesion(){
    return(
                <div id='colores'>
                    <h2>Inicie sesion para ingresar a su cuenta</h2>
                     <form>
                         <label>Ingrese nombre de usuario</label>
                         <br/>
                         <input type={Text} />
                         <br/>
                         <label>Ingrese Contraseña</label>
                         <br/>
                         <input type={Text}/>
                         <br/>
                         <button>Acceder</button>
                     </form>
                </div>
    )
}
