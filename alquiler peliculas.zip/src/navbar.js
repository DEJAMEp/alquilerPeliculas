import React from 'react';

import "./formulario.css";
import filtercap from './contenidoMain';

export default function Navbar(){
return(
    <div className="nav">
        
          <h2 class="nav_logo">Flexin</h2>
       
        <div id='cont-nav'>
        <input onClick={filtercap} id="buscador" className="boton_placeholder" type="search" placeholder="Search"/>
        <button id="search"  placeholder="">buscar</button >
        </div>
        <serction>
          <button id='Logout'> Log out </button>
        </serction>
      </div>
      
)
};
