
import './App.css';
import Navbar from './navbar';

import AppJson from './contenidoMain';






function App() {
  return (
    <>
      <Navbar />
      <AppJson/>
    </>
  );
}

export default App;

